#!/bin/bash
# cerate text file by OCR from all jpg files in ocr_src folder
# names of OCR files are the same as name of jog files

ocr_src="@@INPUT_OCR_DIR@@" # folder with jpg and png files
ocr_exp="@@OUTPUT_OCR_DIR@@" # folder to save text files

if [ ! -d "target/$ocr_exp" ]; then
    mkdir "target/$ocr_exp"
fi

for file in "target/$ocr_src"/*.jpg "target/$ocr_src"/*.png; do
    if [ -f "$file" ]; then
        filename=$(basename "$file")
        filename="${filename%.*}"
        tesseract "$file" "target/$ocr_exp/$filename" -l pol
        echo "Processed file: $filename"
    fi
done

