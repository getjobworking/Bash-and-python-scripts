#!/bin/bash

search_string="$1"
file_extension="$2"

if [ -z "$search_string" ] || [ -z "$file_extension" ]; then
    echo "Usage: ./search.sh \"search_string\" file_extension"
    exit 1
fi

# Searching the entire system for files with the given extension and containing the given word in the name
find / -type f -name "*.$file_extension" -iname "*$search_string*" 2>/dev/null

