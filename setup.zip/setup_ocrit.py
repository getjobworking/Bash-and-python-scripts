import os
import pytesseract
from PIL import Image
import sys

# Set the source and destination folder paths
ocr_src = "@@INPUT_OCR_DIR@@" #target/ocr_src
ocr_exp = "@@OUTPUT_OCR_DIR@@" #target/ocr_exp

# Check if the destination folder exists and create it if it doesn't
if not os.path.exists(ocr_exp):
    os.makedirs(ocr_exp)

# Function to process an image and save the OCR result
def process_image(image_path, language='pol'):
    try:
        # Read the image
        img = Image.open(image_path)

        # Perform OCR
        text = pytesseract.image_to_string(img, lang=language)

        # Save the result to a text file
        filename = os.path.splitext(os.path.basename(image_path))[0]
        with open(os.path.join(ocr_exp, f"{filename}.txt"), "w", encoding='utf-8') as f:
            f.write(text)

        print(f"Processed file: {filename}")
    except Exception as e:
        print(f"Error processing file: {image_path}\n{e}")

# Get the OCR language from the command-line argument or set the default to 'pol'
language = 'pol' if len(sys.argv) < 2 else sys.argv[1]

# Process all files with the extensions '.jpg' and '.png' in the source folder
files = sorted([f for f in os.listdir(ocr_src) if f.lower().endswith((".jpg", ".png"))])
for file in files:
    file_path = os.path.join(ocr_src, file)
    process_image(file_path, language)

