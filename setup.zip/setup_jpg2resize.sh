#!/bin/bash

# Default values for width and quality
default_width=@@SETUP_DEFAULT_WIDTH@@
default_quality=@@SETUP_DEFAULT_QUALITY@@

# Get width and quality from command line arguments
width=${1:-$default_width}
quality=${2:-$default_quality}

input_dir="$HOME/@@SETUP_INPUT_DIR@@"
output_dir="$HOME/@@SETUP_OUTPUT_DIR@@"

if [ ! -d "$output_dir" ]; then
  mkdir "$output_dir"
fi

file_list=()

for file in "$input_dir"/*; do
  filename=$(basename "$file")
  output_file="$output_dir/${filename%.*}_sm.jpg"

  # ImageMagick function convert
  convert "$file" -resize "${width}x" -quality "${quality}%" "$output_file"

  file_list+=("$output_file")
  echo "File resized: $file"
done

echo "Script has finished."

