#!/bin/bash
input_dir="@@INPUT_DIR@@"
input_pdf="$input_dir/$1"
output_pdf=$2
font_name=$3

# Help message to display if no parameters are provided
if [ -z "$input_pdf" ]; then
    echo "Usage: ./change_font.sh <input_pdf> [<output_pdf>] [<font_name>]"
    echo "Change the font in a PDF file."
    echo "Optional arguments:"
    echo "  <output_pdf>   Specify the name of the output PDF file. Default: 'output.pdf'"
    echo "  <font_name>    Specify the name of the new font. Default: 'Arial'"
    exit 1
fi

# Set default values for output_pdf and font_name if not provided
if [ -z "$output_pdf" ]; then
    output_pdf="@@OUTPUT_PDF@@"
fi

if [ -z "$font_name" ]; then
    font_name="@@DEFAULT_FONT@@"
fi

# Create the output directory if it does not exist
output_dir="@@EXPORT_DIR@@"
if [ ! -d "$output_dir" ]; then
    mkdir "$output_dir"
fi

temp_pdf="@@TEMP_PDF@@"

# Uncompress the input PDF to modify its contents
pdftk "$input_pdf" output "$output_dir/$temp_pdf" uncompress

# Replace the existing font with the specified font in the output PDF
sed -i "s|/BaseFont /[^[:space:]]*|/BaseFont /$font_name|g" "$output_dir/$temp_pdf"

# Compress the output PDF after modifying its contents
pdftk "$output_dir/$temp_pdf" output "$output_dir/$output_pdf" compress

# Remove the temporary file
rm "$output_dir/$temp_pdf"

echo "The PDF file was saved as $output_dir/$output_pdf with $font_name replaced."

